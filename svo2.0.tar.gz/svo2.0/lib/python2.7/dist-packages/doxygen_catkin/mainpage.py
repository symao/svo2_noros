mainpage="""/**

\mainpage {0}

This is the mainpage description for the "{0}" project as found in
mainpage.dox.

*/

"""
