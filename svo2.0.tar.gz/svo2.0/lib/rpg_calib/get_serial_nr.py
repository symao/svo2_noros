#!/usr/bin/python
import yaml
import sys

if len(sys.argv) < 2:
    sys.exit("Usage: " + sys.argv[0] + " quad_name.yaml")

stream = open(sys.argv[1], "r")
docs = yaml.load(stream)

sys.stdout.write(str(docs['serial_nr']))
