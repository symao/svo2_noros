#!/usr/bin/python
import yaml
import sys

if len(sys.argv) < 3:
    sys.exit("Usage: " + sys.argv[0] + " quad_name.yaml calib_folder")

stream = open(sys.argv[1], "r")
docs = yaml.load(stream)

sys.stdout.write(sys.argv[2])
sys.stdout.write(docs['calib_file'])
