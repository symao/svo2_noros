#pragma once

#include <kindr/minimal/quat-transformation.h>

namespace rpg_common {

typedef kindr::minimal::QuatTransformation Pose;

}  // namespace rpg_common
namespace rpg = rpg_common;
