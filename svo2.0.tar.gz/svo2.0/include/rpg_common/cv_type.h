#pragma once

namespace rpg_common {

template <typename>
struct CvType
{
  static const int value;
};

}  // namespace rpg_common
namespace rpg = rpg_common;
