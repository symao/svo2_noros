#pragma once

#include <Eigen/Dense>
#include <glog/logging.h>
#include <opencv2/core/core.hpp>

#include "rpg_common/cv_type.h"

namespace rpg_common {

template <typename Type, int Rows, int Cols>
void eigenToCv(const Eigen::Matrix<Type, Rows, Cols>& eigen, cv::Mat* mat)
{
  CHECK_NOTNULL(mat)->create(eigen.rows(), eigen.cols(), CvType<Type>::value);
  Eigen::Map<Eigen::Matrix<Type, Rows, Cols>>(
      reinterpret_cast<Type*>(mat->data), eigen.rows(), eigen.cols()) = eigen;
}

// Transfers each column to an element of the result.
template <typename Type>
void eigenToCv(
    const Eigen::Matrix<Type, Eigen::Dynamic, Eigen::Dynamic>& eigen,
    std::vector<cv::Mat>* result)
{
  CHECK_NOTNULL(result)->resize(eigen.cols());

  for (size_t i = 0u; i < eigen.cols(); ++i)
  {
    (*result)[i].create(eigen.rows(), 1, CvType<Type>::value);
    Eigen::Map<Eigen::Matrix<Type, Eigen::Dynamic, 1>>(
        reinterpret_cast<Type*>((*result)[i].data), eigen.rows()) =
            eigen.col(i);
  }
}

template <typename InType, typename OutType>
void eigenToCv(const Eigen::Matrix<InType, 2, Eigen::Dynamic>& eigen,
               std::vector<cv::Point_<OutType>>* result)
{
  CHECK_NOTNULL(result)->clear();
  for (int i = 0; i < eigen.cols(); ++i)
  {
    result->emplace_back(eigen(0, i), eigen(1, i));
  }
}

template <typename InType>
void eigenToCv(const Eigen::Matrix<InType, 2, Eigen::Dynamic>& eigen,
               std::vector<cv::KeyPoint>* result)
{
  CHECK_NOTNULL(result)->clear();
  for (int i = 0; i < eigen.cols(); ++i)
  {
    result->emplace_back(eigen(0, i), eigen(1, i), 1.);
  }
}

}  // namespace rpg_common
namespace rpg = rpg_common;
