#pragma once

#include <vector>

#include <Eigen/Dense>

namespace rpg_common {

template <typename ObjectType>
class VectorEach;
template <typename ScalarType>
class EigenVectorEach;
template <typename ScalarType>
class EigenRowVectorEach;

template <typename ObjectType>
inline VectorEach<ObjectType> each(const std::vector<ObjectType>& container)
{
  return VectorEach<ObjectType>(container);
}
template <typename ScalarType>
inline EigenVectorEach<ScalarType> each(
    const Eigen::Matrix<ScalarType, Eigen::Dynamic, 1>& matrix)
{
  return EigenVectorEach<ScalarType>(matrix);
}
template <typename ScalarType>
inline EigenRowVectorEach<ScalarType> each(
    const Eigen::Matrix<ScalarType, 1, Eigen::Dynamic>& matrix)
{
  return EigenRowVectorEach<ScalarType>(matrix);
}

template <typename ObjectType>
class VectorEach {
public:
  explicit inline VectorEach(const std::vector<ObjectType>& container) :
  container_(container)
  {}

  inline std::vector<bool> operator ==(const ObjectType& reference) const
    {
      std::vector<bool> result;
      for (const ObjectType& object : container_)
      {
        result.push_back(object == reference);
      }
      return result;
    }

  inline std::vector<bool> operator !=(const ObjectType& reference) const
  {
    std::vector<bool> result;
    for (const ObjectType& object : container_)
    {
      result.push_back(object != reference);
    }
    return result;
  }

private:
  const std::vector<ObjectType>& container_;
};

template <typename ScalarType>
class EigenVectorEach {
public:
  explicit inline EigenVectorEach(
      const Eigen::Matrix<ScalarType, Eigen::Dynamic, 1>& vector) :
      vector_(vector)
  {}

  inline std::vector<bool> operator <(const ScalarType reference) const
  {
    std::vector<bool> result(vector_.size());
    for (int i = 0; i < vector_.size(); ++i)
    {
      result[i] = vector_(i) < reference;
    }
    return result;
  }

  inline std::vector<bool> operator >(const ScalarType reference) const
  {
    std::vector<bool> result(vector_.size());
    for (int i = 0; i < vector_.size(); ++i)
    {
      result[i] = vector_(i) > reference;
    }
    return result;
  }

  inline std::vector<bool> operator !=(const ScalarType reference) const
  {
    std::vector<bool> result;
    for (int i = 0; i < vector_.size(); ++i)
    {
      result.push_back(vector_(i) != reference);
    }
    return result;
  }

private:
  const Eigen::Matrix<ScalarType, Eigen::Dynamic, 1>& vector_;
};

template <typename ScalarType>
class EigenRowVectorEach {
public:
  explicit inline EigenRowVectorEach(
      const Eigen::Matrix<ScalarType, 1, Eigen::Dynamic>& vector) :
      vector_(vector)
  {}

  inline std::vector<bool> operator <(const ScalarType reference) const
  {
    std::vector<bool> result;
    for (int i = 0; i < vector_.size(); ++i)
    {
      result.push_back(vector_(i) < reference);
    }
    return result;
  }

private:
  const Eigen::Matrix<ScalarType, 1, Eigen::Dynamic>& vector_;
};
}  // namespace rpg_common
namespace rpg = rpg_common;
