#pragma once

#include <svo/common/camera_fwd.h>

# include <vikit/cameras/ncamera.h>
# include <vikit/cameras/camera_geometry_base.h>
