#pragma once

/* #undef SVO_WITH_CUDA */
/* #undef SVO_WITH_PANGOLIN */
